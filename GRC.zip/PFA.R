#####ADMM for Transfer Learning
##Packages: Matrix
# rm(list=ls())
library(Matrix)
library(tidyverse)
library(fossil) # package for evaluating clustering

######some auxiliary functions##################################################
###S function for group lasso----------------------------------
S<-function(a,b){
  ##a is a vector and b is a number
  l2norm=norm(as.matrix(a),'2')
  res=max((1-b/l2norm),0)*a
  return(res)
}

##mcp solution based on this optimization--------------------------------------
#gamma_pra > 1/vartheta
mcp<-function(a,gamma_pra,lambda_1,vartheta){
  l2norm=norm(as.matrix(a),'2')
  if(l2norm<=(gamma_pra*lambda_1)){res=S(a,lambda_1/vartheta)/(1-1/(gamma_pra*vartheta))}
  else {res=a}
  return(res)
}


###scad solution based on this optimization--------------------------------------
##gamma_pra > 1/vartheta+1
scad<-function(a,gamma_pra,lambda_1,vartheta){
  l2norm=norm(as.matrix(a),'2')
  if(l2norm<= (lambda_1+lambda_1/vartheta)){res=S(a,lambda_1/vartheta)}
  else if(l2norm>(gamma_pra*lambda_1)){res=a}
  else {num=(gamma_pra-1)*vartheta;res=S(a,gamma_pra*lambda_1/num)/(1-1/num)}
  return(res)
}

###############################################################################
###ADMM Algorithm--------------------------------------------------------------
admm<-function(y,X,penalty='MCP',gamma_pra=3.7,lambda=0.01,
               vartheta=0.45,res=1e-04,M=100){
  ##gamma_pra: the tuning parameter in MCP or SCAD
  ##vartheta: the tunning parameter in ADMM
  ##res:the residual for stopping
  
  ##M: the maximum number of iterations
  n=nrow(X);p=ncol(X);
  mlist=list()
  for(i in 1:n){mlist[[i]]=X[i,]}
  X_diag=t(bdiag(mlist))
  D=Matrix(0,nrow=n,ncol=n*(n-1)/2,sparse = TRUE)
  for(i in 1:(n-1)){D[(1:(i+1)),((i*(i-1)/2+1):(i*(i+1)/2))]=rbind(-diag(i),rep(1,i))}
  D=t(D)
  I_p=diag(p)#####high-dimension need to be sparse
  A=kronecker(D,I_p)
  
  
  ######################################################################
  ##initial values------------------------------------------
  lambda_0=0.001
  beta_r=solve(t(X_diag)%*%X_diag+lambda_0*t(A)%*%A)%*%t(X_diag)%*%y
  
  # Kstar=floor(sqrt(n))
  # beta_r_matrix=matrix(beta_r,n,p,byrow = T)
  # beta_median=apply(beta_r_matrix,1,median)
  # num_k=floor(n/Kstar)
  # beta_median_rank=rank(beta_median)
  # for (i in 1:Kstar) {
  #   index_s=((i-1)*num_k+1)
  #   index_e=(i*num_k)
  #   if(i==Kstar){index_e=n}
  #   index_i=NULL
  #   for (j in seq(index_s,index_e)) {
  #     index_i=c(index_i,which(beta_median_rank==j))
  #   }
  #   temp=solve(t(X[index_i,])%*%X[index_i,])%*%t(X[index_i,])%*%y[index_i]
  #   beta_r_matrix[index_i,]=matrix(rep(temp,length(index_i)),nrow = length(index_i),byrow=T)
  # }
  # beta_r=as.vector(t(beta_r_matrix))
  
  delta_0=NULL
  upsilon_0=rep(0,(p*n*(n-1)/2))
  
  ############################################################
  Beta_r=matrix(beta_r,nrow = p,ncol = n)
  for (i in 2:n) {
    delta_0=c(delta_0,as.vector(matrix(rep(Beta_r[,i],(i-1)),nrow=p,ncol = (i-1))-Beta_r[,1:(i-1)]))
  }
  
  ###initial space-----------------------------
  beta=beta_r
  delta=delta_0
  upsilon=upsilon_0
  
  beta_0=solve(t(X_diag)%*%X_diag+vartheta*t(A)%*%A)
  beta_1=beta_0%*%t(X_diag)%*%y
  
  ###----------------------------------------------------------
  R=1e+6 ##the primal residual
  m=0
  ###---------------------------------------------------------------------
  while ((norm(R,'2')>res) & (m < M)) {
    R_before=R
    print(paste('    ','At iteration ',m,', R=',norm(R,'2'),sep = ''))
    ##update beta---------------
    beta_2=vartheta*t(A)%*%(delta-1/vartheta*upsilon)
    beta=beta_1+beta_0%*%beta_2
    ##update delta and update upsilon---------------
    B=matrix(beta,nrow = p,ncol = n)
    zeta0=NULL
    for (i in 2:n) {
      B_i=matrix(rep(B[,i],(i-1)),nrow=p,ncol = (i-1))
      B_j=B[,1:(i-1)]
      zeta0=c(zeta0,as.vector(B_i-B_j))
    }
    zeta=zeta0+(1/vartheta)*upsilon
    zeta=matrix(zeta,nrow = p,ncol = n*(n-1)/2)
    if(penalty=='Group LASSO'){
      delta=as.vector(apply(zeta,2,S,b=lambda/vartheta))
    }else if(penalty=='MCP'){
      delta=as.vector(apply(zeta,2,mcp,gamma_pra=gamma_pra,lambda_1=lambda,vartheta=vartheta))
    }else{
      delta=as.vector(apply(zeta,2,scad,gamma_pra=gamma_pra,lambda_1=lambda,vartheta=vartheta))
    }
    ##--update upsilon-------------------------
    tempdiff=zeta0-delta
    upsilon=upsilon+vartheta*tempdiff
    ###------------------------------
    R=A%*%beta-delta
    if(norm(R,'2')>norm(R_before,'2')){break}
    m=m+1
  }###while
  out=list(beta=beta,delta=delta,upsilon=upsilon)
  return(out)
}



sumResults_PFA <- function(betahat0, x, y, N){
  # 汇总PFA的模拟结果，返回cluster, centers
  # 采用 global kmeans 方法
  # betahat0 = betahat_init[[i]]; x = X[[i]]; y = Y[[i]]
  n = length(y)
  sse = numeric()
  centers = list()
  clusters = list()
  centers_seq = colMeans(betahat0)
  clusters[[1]] = rep(1, n)
  centers[[1]] = centers_seq
  sse[1] = mean((y-x%*%solve(t(x)%*%x, t(x)%*%y))^2)
  for(k in 2:N){
    posi = which.min(apply(betahat0, 1, function(v) kmeans(betahat0, rbind(centers_seq, v))$tot.withinss))
    clust_result = kmeans(betahat0, rbind(centers_seq, betahat0[posi, ]))
    centers_seq = clust_result$centers # 这个center是根据betahat0 估计出来的
    clusters[[k]] = clust_result$cluster
    cluster_mem = lapply(1:k, function(v) which(clust_result$cluster == v))
    centers_coef = sapply(cluster_mem, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g]) # 这个center是回归模型的系数
    centers[[k]] = centers_coef
    sse = c(sse, sum(sapply(1:k, function(i) sum( (y[cluster_mem[[i]]]-x[cluster_mem[[i]],]%*%centers_coef[, i])^2)))/n)
  }
  diff_sse = sse[1:(N-1)] - sse[-1]
  n = length(y)
  c = 1/log(n)
  K_opt = which.min( (diff_sse[-1]+c)/(diff_sse[1:(N-2)]+c) ) + 1
  return(list(clusters = clusters[[K_opt]], centers = centers[[K_opt]]))
}







