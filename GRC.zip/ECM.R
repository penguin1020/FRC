# ECM algorithm
# This algorithm is from the paper 
ECM <- function(x, y, N){
  n <- nrow(x)
  d <- ncol(x)
  betahat = solve(t(x)%*%x)%*%t(x)%*%y
  clusters_seq = rep(1, n)
  SSE = sum((y-x%*%betahat)^2)/n # SSE with only one cluster
  
  for(J in 2:N){
    # J is the number of cluster in current stage
  
    SigMat = matrix(rep(rep(1, J), n), ncol=J, byrow = T)
    diff_loglike = 1
    iter = 1 # indicating the iterations
    pi_hat = rep(1/J, J)
    Bnew = global_kmeans(x, y, J)
    Phi = (sqrt(2*pi*SigMat))^-1*exp(-(matrix( rep(y, J), ncol=J) - x%*%Bnew)^2/(2*SigMat))
    # if Phi is 0, make it positive
    Phi[Phi==0] = 1e-5

    # running the ECM algorithm to produce the right clusters
    while(diff_loglike > 1e-5){
      # E-step
      weight = Phi*matrix(rep(pi_hat, n), ncol=J, byrow = T)/as.vector(Phi%*%pi_hat)
      loglike_old = sum(log(Phi%*%pi_hat))
      
      # C-step
      clusters = apply(weight, 1, which.max)
      if(length(unique(clusters)) < J){
        break
      }
      clusters_mem = lapply(as.list(1:J), function(k) which(clusters == k))
      pi_hat = sapply(as.list(1:J), function(k) mean(clusters == k))
      
      # M-step
      Bnew = matrix(0, d, J)
      lam = 0.001
      for(j in 1:J){
        xj = x[clusters == j, ]
        wj = weight[clusters == j, j]
        yj = y[clusters == j]
        if(length(wj) == 1){
          gram_mat = wj*xj%*%t(xj)
          grad_vec = wj*xj*yj
        }else{
          gram_mat = t(xj)%*%diag(wj)%*%xj
          grad_vec = t(xj)%*%diag(wj)%*%yj
        }
        if(is.singular.matrix(gram_mat)){
          # if the matrix is singular, using the ridge estimator
          Bnew[, j] = solve(gram_mat + diag(lam,d,d))%*%grad_vec
        }else{
          Bnew[, j] = solve(gram_mat)%*%grad_vec
        }
      }
      SigMat = colSums(weight*(matrix(rep(y, J), ncol=J) - x%*%Bnew)^2)/colSums(weight)
      # log-likelihood
      Phi = (sqrt(2*pi*SigMat))^-1*exp(-(matrix(rep(y, J), ncol=J) - x%*%Bnew)^2/(2*SigMat))
      loglike_new = sum(log(Phi%*%pi_hat))
      diff_loglike = abs(loglike_new - loglike_old)
      iter = iter + 1
      # print(Ghat); print(Bnew)
      if(iter >= 50){break}
      # print(diff_loglike)
    }
    
    weight = Phi*matrix(rep(pi_hat, n), ncol=J, byrow = T)/as.vector(Phi%*%pi_hat)
    clusters = apply(weight, 1, which.max)
    clusters_seq <- rbind( clusters_seq, clusters )
    clusters_mem = lapply(as.list(1:J), function(v) which(clusters == v))
    if(min(sapply(clusters_mem, length))<=d){break}else{
      SSE = c( SSE, sum(sapply(clusters_mem, function(g) 
        sum((y[g]-x[g,]%*%solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])^2)))/n )
    }
    
  }
  
  K <- length(SSE)
  # BIC <- log(n)*(1:K) + 2*log(SSE)
  AIC <- 2*(1:K) + 2*log(SSE)
  K_opt <- which.min(AIC)
  clusters = clusters_seq[K_opt, ]
  clusters_mem = lapply(as.list(1:K_opt), function(v) which(clusters == v))
  centers = sapply(clusters_mem, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])
  
  return(list(clusters = clusters, centers = centers))
  
}


