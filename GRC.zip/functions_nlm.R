GRC_nlm <- function(x, y, anchors, modelNo = 1){
  n = length(y)
  p = ncol(x)
  N = ncol(anchors)  # update the value of N
  
  ## 开始时只设置一个group
  x1 = x[, 1]
  x2 = x[, 2]
  if(modelNo == 1){
    model = nls(y ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 1))
    initials = coefficients(model)
    SSE_outer = sum((y-(x%*%initials)^3)^2) # SSE with only one cluster
  }else if(modelNo == 2){
    model = nls(y ~ sin(pi*b1*x1) + b2*x2, start = list(b1 = 1, b2 = 0))
    initials = coefficients(model)
    SSE_outer = sum((y-sin(pi*x[, 1]*initials[1]) - x[, 2]*initials[2])^2)  # SSE with only one cluster
  }
  
  clusters_seq = rep(1, n)
  k = 2 # 从k=2开始
  while(length(SSE_outer) < N){
    SSE_inner = NULL
    for(l in 1:N){
      clusters_inner = local_kmeans_nlm(x, y, cbind(initials, anchors[, l]), modelNo = 2)
      # finding the membership in the cluster
      clusters_inner_mem = lapply(as.list(1:k), function(v) which(clusters_inner == v))
      SSE_temp = 0
      for(j in 1:k){
        g_temp = clusters_inner_mem[[j]]
        x1 = x[g_temp, 1]
        x2 = x[g_temp, 2]
        yg = y[g_temp]
        if(modelNo == 1){
          model = nls(yg ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 1))
          betahat_temp = coefficients(model)
          SSE_temp = SSE_temp + sum( (yg - (x[g_temp, ]%*%betahat_temp)^3)^2 )
        }else if(modelNo == 2){
          model = nls(yg~sin(pi*x1*b1)+x2*b2, start = list(b1=1,b2=0))
          betahat_temp = coefficients(model)
          SSE_temp = SSE_temp + sum( (yg - sin(pi*x1*betahat_temp[1]) - x2*betahat_temp[2])^2 )
        }
      }
      SSE_inner = c(SSE_inner, SSE_temp)
    }
    
    # find the sample minimizes the SSE 
    i_min = which.min(SSE_inner)
    clusters_opt = local_kmeans_nlm(x, y, cbind(initials, anchors[, i_min]), modelNo)
    clusters_opt_mem = lapply(as.list(1:k), function(v) which(clusters_opt == v))
    
    coef_new = matrix(0, p, k)
    for(j in 1:k){
      g_temp = clusters_opt_mem[[j]]
      x1 = x[g_temp, 1]
      x2 = x[g_temp, 2]
      yg = y[g_temp]
      if(modelNo == 1){
        model = nls(yg ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 0))
      }else if(modelNo == 2){
        model = nls(yg ~ sin(pi*b1*x1)+ b2*x2, start = list(b1 = 1, b2 = 0))
      }
      coef_new[, j] = coefficients(model)
    }
    initials = coef_new
    SSE_outer = c(SSE_outer, SSE_inner[which.min(SSE_inner)])
    clusters_seq = rbind(clusters_seq, clusters_opt)
    k = k + 1
    
  }
  
  # employ TDRR criterion to estimate the optimal K_opt
  diff_SSE = SSE_outer[1:(N-1)] - SSE_outer[-1]
  c = 1/log(n)
  K_opt = which.min( (diff_SSE[-1]+c)/(diff_SSE[1:(N-2)]+c) ) + 1
  clusters = clusters_seq[K_opt, ]
  clusters_mem = lapply(as.list(1:K_opt), function(v) which(clusters == v))
  
  # get the centers 
  centers = matrix(0, p, K_opt)
  for(j in 1:K_opt){
    g_temp = clusters_mem[[j]]
    x1 = x[g_temp, 1]
    x2 = x[g_temp, 2]
    yg = y[g_temp]
    if(modelNo == 1){
      model = nls(yg ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 1))
    }else{
      model = nls(yg ~ sin(pi*b1*x1)+ b2*x2, start = list(b1 = 1, b2 = 0))
    }
    centers[, j] = coefficients(model)
  }
  return(list(clusters = clusters, centers = centers))
}


local_kmeans_nlm <- function(x, y, initials, modelNo){
  # initials is a coef matrix with column be parameter estimate
  # initials must be an matrix with coulmns larger than 1
  # initials = cbind(initials, anchors[, l])
  bound = 1
  lam = 0.01 # tuning parameter of ridge estimate
  coef_old = initials
  K = ncol(coef_old)
  n = length(y)
  iter = 1
  iter_max = 100
  while(bound > 1e-2){
    K = ncol(coef_old)
    p = nrow(coef_old)
    if(modelNo == 1){
      MSE = apply(coef_old, 2, function(v) (y - (x%*%v)^3)^2) # compute MSE
    }else if(modelNo == 2){
      MSE = apply(coef_old, 2, function(v) (y - sin(pi*v[1]*x[, 1]) - x[, 2]*v[2])^2)
    }
    clusters = apply(MSE, 1, which.min)
    coef_new = matrix(0, p, K)
    for(k in 1:K){
      g = which(clusters == k) # elements in the k-th cluster
      x1 = x[g, 1]
      x2 = x[g, 2]
      yg = y[g]
      if(modelNo == 1){
        model = nls(yg ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 0))
        coef_new[, k] = coefficients(model)
      }else if(modelNo == 2){
        model = nls(yg ~ sin(b1*pi*x1)+b2*x2, start = list(b1 = 1, b2 = 0))
        coef_new[, k] = coefficients(model)
      }
    }
    bound = max( (coef_new - coef_old)^2 )
    coef_old = coef_new
    # print(bound)
    iter = iter + 1
    if(iter > iter_max){
      break
    }
  }
  return(clusters)
}



getAnchors <- function(x,y, N, modelNo = 1){
  # N is the number of pre-determined cluster
  n <- nrow(x)
  d <- ncol(x)
  load("D200.Rdata") 
  H0 = matrix(0,n*d,n*d)
  grad0 <- matrix(0, n*d, 1)
  err <- 1
  lambda <- 0.01
  iter <- 1
  beta0 <- matrix(rep(c(1,1),n), 2)
  while(err > 1e-2){
    if(modelNo == 1){
      for(i in 1:n){
        xb <- x[i, ]%*%beta0[, i]
        grad0[((i-1)*d+1):(i*d)] = 3*x[i,]*as.numeric(xb^5 - y[i]*xb^2)
        H0[((i-1)*d+1):(i*d), ((i-1)*d+1):(i*d)] <- 
          x[i,]%*%t(x[i,])*as.numeric(15*xb^4-6*y[i]*xb)
      }
    }else if(modelNo == 2){
      for(i in 1:n){
        xi1 = x[i, 1]
        xi2 = x[i, 2]
        betai = beta0[, i]
        grad01 = 2*(y[i]-sin(xi1*betai[1]*pi)-(xi2*betai[2]+1)^2)*(-cos(xi1*betai[1]*pi)*pi*xi1)
        grad02 = 2*(y[i]-sin(xi1*betai[1]*pi)-(xi2*betai[2]+1)^2)*(-2*xi2*(betai[2]*xi2+1))
        grad0[((i-1)*d+1):(i*d)] = c(grad01, grad02)
        h11 = 2*(pi*xi1)^2*cos(pi*xi1*betai[1])^2-
          2*(pi*xi1)^2*sin(betai[1]*pi*xi1)*(y[i]-sin(xi1*betai[1]*pi)-(xi2*betai[2]+1)^2)
        h12 = 4*pi*xi1*xi2*(betai[2]*xi2+1)*cos(betai[1]*pi*xi1)
        h21 = h12
        h22 = 8*xi2^2*(betai[2]*xi2+1)^2-4*(y[i]-sin(betai[1]*pi*xi1)-(xi2*betai[2]+1)^2)*xi2^2
        H0[((i-1)*d+1):(i*d), ((i-1)*d+1):(i*d)] <- matrix(c(h11,h12,h21,h22),2)
      }
    }
    grad  <- grad0 + lambda*D[[d]]%*%c(beta0)
    H     <- H0 + lambda*D[[d]]
    beta1 <- c(beta0) - solve(H)%*%grad
    beta1 <- matrix(beta1, 2)
    err <- max(abs(beta1 - beta0))
    beta0 <- beta1
    # print(err)
    iter <- iter + 1
    if(iter > 100){
      break
    }
  }
  betahat_all = matrix(beta0, 2)
  # 这里可以更换非动态方法。
  anchors = t( kmeans(t(betahat_all), N)$centers ) # anchors 看作聚类的锚点
  return(anchors)
}


getAnchors2 <- function(x,y, N, modelNo = 1){
  # x = data$x; y = data$y
  d = ncol(x)
  u = cbind(x, y)
  centers = colMeans(u)
  clusters_seq = 1:n
  for(i in 2:N){
    posi = which.min(apply(u, 1, function(v) kmeans(u, rbind(centers, v))$tot.withinss))
    clust_result = kmeans(u, rbind(centers, u[posi, ]))
    centers = clust_result$centers
    clusters = clust_result$cluster
    clusters_seq = rbind(clusters_seq, clusters)
    # The following block code is to prevent the cluster 
    # having the number of elements smaller thant d
    if(min(tabulate(clusters)) <= d){
      N = i - 1
      clusters = clusters_seq[i-1, ]
      break
    }
  }
  clusters_mem = lapply(as.list(1:N), function(v) which(clusters == v))
  centers = matrix(0, d, N)
  for(k in 1:N){
    yk = y[clusters_mem[[k]]]
    xk = x[clusters_mem[[k]], ]
    xk1 = xk[, 1]
    xk2 = xk[, 2]
    if(modelNo == 1){
      model = nls(y ~ (b1*x1+b2*x2)^3, start = list(b1 = 1, b2 = 1))
    }else if(modelNo == 2){
      model = nls(yk~sin(b1*pi*xk1)+ b2*xk2, start = list(b1=1, b2=0))
    }
    centers[, k] = coef(model)
  }
  return(centers)
}




evaluate_estimate = function(coef, coefhat){
  # only compute the iteration in which the numbers of clusters are correctlly estimated
  # first pick up the right clusters
  K = ncol(coef)
  d = nrow(coef)
  K_hat = sapply(coefhat, ncol)
  if(sum(K_hat==K) == 0){
    return(cbind(rep(0, K), rep(0, K)))
  }else{
    pr = mean(K_hat == K)
    coefhat = coefhat[K_hat == K]
    RMSE = NULL
    for(k in 1:K){
      coefhat_k = sapply(coefhat, function(x) x[, which.min(sqrt(colMeans( (x - coef[, k])^2 )) )] )
      RMSE = cbind( RMSE, sqrt( colMeans( (coefhat_k - coef[, k])^2 ) ) )
    }
    RMSE_mean = round(apply(RMSE, 2, mean), 4)
    RMSE_sd = round(apply(RMSE, 2, sd), 4)
    return(cbind(RMSE_mean, RMSE_sd))
  }
}

