evaluate_estimate = function(coef, coefhat){
  # only compute the iteration in which the numbers of clusters are correctlly estimated
  # first pick up the right clusters
  K = ncol(coef)
  d = nrow(coef)
  K_hat = sapply(coefhat, ncol)
  if(sum(K_hat==K) == 0){
    return(cbind(rep(0, K), rep(0, K)))
  }else{
    pr = mean(K_hat == K)
    coefhat = coefhat[K_hat == K]
    RMSE = NULL
    for(k in 1:K){
      coefhat_k = sapply(coefhat, function(x) x[, which.min(sqrt(colMeans( (x - coef[, k])^2 )) )] )
      RMSE = cbind( RMSE, sqrt( colMeans( (coefhat_k - coef[, k])^2 ) ) )
    }
    RMSE_mean = round(apply(RMSE, 2, mean), 4)
    RMSE_sd = round(apply(RMSE, 2, sd), 4)
    return(cbind(RMSE_mean, RMSE_sd))
  }
}



global_kmeans <- function(x, y, N){
  n = nrow(x)
  p = ncol(x)
  u = cbind(x, y)
  centers = colMeans(u)
  clusters_seq = 1:n
  for(i in 2:N){
    posi = which.min(apply(u, 1, function(v) kmeans(u, rbind(centers, v))$tot.withinss))
    clust_result = kmeans(u, rbind(centers, u[posi, ]))
    centers = clust_result$centers
    clusters = clust_result$cluster
    clusters_seq = rbind(clusters_seq, clusters)
    # The following block code is to prevent the cluster having only one element
    if(min(tabulate(clusters)) <= p){
      N = i - 1
      clusters = clusters_seq[i-1, ]
      break
    }
  }
  clusters_mem = lapply(as.list(1:N), function(v) which(clusters == v))
  d = ncol(x)
  centers = sapply(clusters_mem, function(g) solve(t(x[g,])%*%x[g,]+0.001*diag(d))%*%t(x[g,])%*%y[g])
  return(centers)
}


