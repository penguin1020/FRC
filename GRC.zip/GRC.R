library(matrixcalc)
# algorithm 1
local_kmeans_lm = function(x, y, initials){
  # initials is a coef matrix with column be parameter estimate
  # initials must be an matrix with coulmns larger than 1
  bound = 1
  lam = 0.01 # tuning parameter of ridge estimate
  coef_old = initials
  while(bound > 1e-6){
    K = ncol(coef_old)
    p = nrow(coef_old)
    MSE = apply(coef_old, 2, function(v) (y - x%*%v)^2) # compute MSE
    clusters = apply(MSE, 1, which.min)
    coef_new = matrix(0, p, K)
    for(k in 1:K){
      lam = 0.01
      g = which(clusters == k) # elements in the k-th cluster
      xg = x[g, ]
      if(length(g) == 1){
        xg = t(as.matrix(x[g, ])) # make xg an matrix form
      }
      gram_mat = t(xg)%*%xg
      if(is.singular.matrix(gram_mat)){
        # if the matrix is singular, useing the ridge estimator
        coef_new[, k] = solve(gram_mat + diag(lam,p,p))%*%t(xg)%*%y[g]
      }else{
        coef_new[, k] = solve(gram_mat)%*%t(xg)%*%y[g]
      }
    }
    bound = max( (coef_new - coef_old)^2 )
    coef_old = coef_new
  }
  return(clusters)
}

# algorithm 2
GRC <- function(x, y, N){
  n = length(y)
  initial_1 = solve(t(x)%*%x)%*%t(x)%*%y # only one cluster
  initials = initial_1
  betahat_single = t(solve(t(x)%*%x/n)%*%t(x))*y
  SSE_outer = sum((y-x%*%initial_1)^2)/n
  clusters_seq = list()
  clusters_seq[[1]] = 1:n
  k = 2
  while(length(SSE_outer) < N){
    SSE_inner = rep(0, n)
    for(i in 1:n){
      clusters_inner = local_kmeans_lm(x, y, cbind(initials, betahat_single[i, ]))
      SSE_inner[i] = sum(sapply(clusters_inner, function(g) 
        sum((y[g]-x[g,]%*%solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])^2)))/n
    }
    # find the sample minimizes the SSE
    i_min = which.min(SSE_inner)
    clusters_opt = local_kmeans_lm(x, y, cbind(initials, betahat_single[i_min, ]))
    coef_new = sapply(clusters_opt, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])
    initials = coef_new
    SSE_outer = c(SSE_outer, SSE_inner[i_min])
    clusters_seq[[k]] = clusters_opt
    k = k + 1
  }
  diff_SSE = SSE_outer[1:(N-1)] - SSE_outer[-1]
  c = 1/log(n)
  K_opt = which.min( (diff_SSE[-1]+c)/(diff_SSE[1:(N-2)]+c) ) + 1
  clusters = clusters_seq[[K_opt]]
  centers = sapply(clusters, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])
  return(list(clusters = clusters, centers = centers))
}

# algorithm 2
GRC_modified <- function(x, y, N){
  n = length(y)
  p = ncol(x)
  initials = solve(t(x)%*%x)%*%t(x)%*%y
  betahat_kmeans = global_kmeans(x, y, N)
  N = ncol(betahat_kmeans) # update the value of N
  # betahat_kmeans = kmeans(betahat_single, N)$centers # local kmeans method
  SSE_outer = sum((y-x%*%initials)^2)/n # SSE with only one cluster
  clusters_seq = rep(1, n)
  k = 2
  while(length(SSE_outer) < N){
    SSE_inner = NULL
    for(i in 1:N){
      clusters_inner = local_kmeans_lm(x, y, cbind(initials, betahat_kmeans[, i]))
      clusters_inner_mem = lapply(as.list(1:k), function(v) which(clusters_inner == v))
      # if one cluster only have one element: next
      if(min(sapply(clusters_inner_mem, length))<=p){next}else{
        SSE_inner = c( SSE_inner, sum(sapply(clusters_inner_mem, function(g)
          sum((y[g]-x[g,]%*%solve(t(x[g,])%*%x[g,]+0.001*diag(p))%*%t(x[g,])%*%y[g])^2)))/n )
      }
    }
    # find the sample minimizes the SSE
    i_min = which.min(SSE_inner)
    clusters_opt = local_kmeans_lm(x, y, cbind(initials, betahat_kmeans[, i_min]))
    clusters_opt_mem = lapply(as.list(1:k), function(v) which(clusters_opt == v))
    coef_new = sapply(clusters_opt_mem, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])
    initials = coef_new
    SSE_outer = c(SSE_outer, SSE_inner[which.min(SSE_inner)])
    clusters_seq = rbind(clusters_seq, clusters_opt)
    k = k + 1
  }
  diff_SSE = SSE_outer[1:(N-1)] - SSE_outer[-1]
  c = 1/log(n)
  seqq = (diff_SSE[-1]+c)/(diff_SSE[1:(N-2)]+c)
  if(any(seqq <= 0.5)){
    K_opt = which.min( seqq ) + 1
  }else{
    K_opt = 1
  }
  clusters = clusters_seq[K_opt, ]
  clusters_mem = lapply(as.list(1:K_opt), function(v) which(clusters == v))
  centers = sapply(clusters_mem, function(g) solve(t(x[g,])%*%x[g,])%*%t(x[g,])%*%y[g])
  return(list(clusters = clusters, centers = centers))
}





