# rm(list=ls())
library(fossil) # package for evaluating clustering
library(plot3D)
source("functions_lm.R")
source("DGP.R")

iter = 10
X = list()
Y = list()
Clusters = list()
for(i in 1:iter){
  data <- DGP_lm(n = 300, exNo=1, case = 1)
  # data <- DGP_nlm(n = 300, case = 2)
  X[[i]] <- data$x
  Y[[i]] <- data$y
  # x = data$x; y = data$y; plot(x[, 2], y)
  Clusters[[i]] <- data$clusters0
}

N = 6
results_FRC_modified <- lapply(1:iter, function(i) try(FRC_modified(X[[i]], Y[[i]], N), TRUE))
id_FRC  <- which( sapply(results_FRC_modified, function(v) !("try-error"%in%class(v))) )
RI_FRC  <- sapply(id_FRC, function(i) rand.index(results_FRC_modified[[i]]$clusters, Clusters[[i]]))
ARI_FRC <- sapply(id_FRC, function(i) adj.rand.index(results_FRC_modified[[i]]$clusters, Clusters[[i]]))
K_FRC   <- sapply(id_FRC, function(i) ncol(results_FRC_modified[[i]]$centers))
coefhat_FRC_modified <- lapply(id_FRC, function(i) results_FRC_modified[[i]]$centers)

results_ECM <- lapply(1:iter, function(i) try(ECM(X[[i]], Y[[i]], N), TRUE))
id_ECM <- which( sapply(results_ECM, function(v) !("try-error"%in%class(v))) )
RI_ECM <- sapply(id_ECM, function(i) rand.index(results_ECM[[i]]$clusters, Clusters[[i]]))
ARI_ECM <- sapply(id_ECM, function(i) adj.rand.index(results_ECM[[i]]$clusters, Clusters[[i]]))
K_ECM <- sapply(id_ECM, function(i) ncol(results_ECM[[i]]$centers))
coefhat_ECM <- lapply(id_ECM, function(i) results_ECM[[i]]$centers)

results_CWM <- lapply(1:iter, function(i) try(flexibleCWM(X[[i]], Y[[i]], N), TRUE))
id_CWM <- which( sapply(results_CWM, function(v) !("try-error"%in%class(v))) )
RI_CWM <- sapply(id_CWM, function(i) rand.index(results_CWM[[i]]$clusters, Clusters[[i]]))
ARI_CWM <- sapply(id_CWM, function(i) adj.rand.index(results_CWM[[i]]$clusters, Clusters[[i]]))
K_CWM <- sapply(id_CWM, function(i) ncol(results_CWM[[i]]$centers))
coefhat_CWM <- lapply(id_CWM, function(i) results_CWM[[i]]$centers)

# PFA method
betahat_init = lapply(1:iter, function(i) admm(Y[[i]], X[[i]])$beta %>% matrix(ncol = 2, byrow = T))
results_PFA = lapply(1:iter, function(i) try(sumResults_PFA(betahat_init[[i]], X[[i]], Y[[i]], N=5), TRUE))
id_PFA <- which( sapply(results_PFA, function(v) !("try-error"%in%class(v))) )
RI_PFA <- sapply(id_PFA, function(i) rand.index(results_PFA[[i]]$clusters, Clusters[[i]]))
ARI_PFA <- sapply(id_PFA, function(i) adj.rand.index(results_PFA[[i]]$clusters, Clusters[[i]]))
K_PFA <- sapply(id_PFA, function(i) ncol(results_PFA[[i]]$centers))
coefhat_PFA <- lapply(id_PFA, function(i) results_PFA[[i]]$centers)
round(c(mean(K_PFA == K), mean(RI_PFA), mean(ARI_PFA),
        as.vector(rowMeans(t(evaluate_estimate(coef, coefhat_PFA))) ) ), 4)


K = 4
sumRes_FRC_modified = c(mean(K_FRC == K), mean(RI_FRC), mean(ARI_FRC), 
                        as.vector(t(colMeans(evaluate_estimate(coef, coefhat_FRC_modified)))) )
sumRes_ECM = c(mean(K_ECM == K), mean(RI_ECM), mean(ARI_ECM), 
               as.vector(t(colMeans(evaluate_estimate(coef, coefhat_ECM)))) )
sumRes_CWM = c(mean(K_CWM == K), mean(RI_CWM), mean(ARI_CWM), 
               as.vector(t(colMeans(evaluate_estimate(coef, coefhat_CWM)))) )
sumRes_PFA = c(mean(K_PFA == K), mean(RI_PFA), mean(ARI_PFA), 
               as.vector(t(colMeans(evaluate_estimate(coef, coefhat_PFA)))) )
View( round(rbind(sumRes_FRC_modified, sumRes_ECM, sumRes_CWM, sumRes_PFA), 4) )




# t_start = Sys.time()
# t_end = Sys.time()
# run_time = t_end - t_start

K = 1
sumRes_FRC_modified = c(mean(K_FRC == K), mean(RI_FRC), mean(ARI_FRC), 
                         as.vector(t(colMeans(evaluate_estimate(coef, coefhat_FRC_modified)))) )
sumRes_ECM = c(mean(K_ECM == K), mean(RI_ECM), mean(ARI_ECM), 
                as.vector(t(colMeans(evaluate_estimate(coef, coefhat_ECM)))) )
sumRes_CWM = c(mean(K_CWM == K), mean(RI_CWM), mean(ARI_CWM), 
                as.vector(t(colMeans(evaluate_estimate(coef, coefhat_CWM)))) )
sumRes_PFA = c(mean(K_PFA == K), mean(RI_PFA), mean(ARI_PFA), 
               as.vector(t(colMeans(evaluate_estimate(coef, coefhat_PFA)))) )
View( round(rbind(sumRes_FRC_modified, sumRes_ECM, sumRes_CWM, sumRes_PFA), 4) )




