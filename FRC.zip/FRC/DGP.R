DGP_lm = function(n, exNo = 1, case = 1, err = "std"){
  # coef is a coefficients matrix: columns is the number of clusters.
  # row is the dimension
  # model: y = z*theta + x*beta_i + e
  if(exNo == 1){
    # type1 
    if(case == 1){
      coef = cbind(c(20,4),c(-10,10),c(0,4))
      K = ncol(coef)
      id = sample(1:K, n, replace = TRUE)
      x = matrix(0, n, 2)
      x[id == 1, ] = cbind(rep(1, sum(id==1)), runif(sum(id==1),  0, 5))
      x[id == 2, ] = cbind(rep(1, sum(id==2)), runif(sum(id==2),  1, 6))
      x[id == 3, ] = cbind(rep(1, sum(id==3)), runif(sum(id==3),  2, 7))
    }else{
      coef = cbind(c(0,2),c(8,2),c(16,-2),c(24,-2))
      K = ncol(coef)
      id = sample(1:K, n, replace = TRUE)
      x = cbind(rep(1,n),runif(n, 0, 10))
    }
    y = rep(0, n)
    for(k in 1:K){
      y[id == k] = x[id == k, ]%*%coef[, k]
    }
    y = as.vector( y + sqrt(2)*rnorm(n) ) #rnorm(n)
    # plot(x[, 2], y)
  }else if(exNo == 2){
    coef = cbind(c(-case,-case), c(case,case))
    d = nrow(coef)
    rho = 0.5
    R = chol(matrix(rho, d,d)^abs(matrix(1:d, d,d)-t(matrix(1:d,d,d))))
    K = ncol(coef)
    id = sample(1:K, n, replace = TRUE)
    d = nrow(coef)
    x = matrix(rnorm(n*d), n, d)%*%R
    y = rep(0, n)
    for(k in 1:K){
      y[id == k] = x[id == k, ]%*%coef[, k]
    }
    if(err == "std"){
      y = as.vector( y + rnorm(n) )
    }else{
      y = as.vector( y + rt(n, 3))
    }
     #rnorm(n) rt(n, 3)
  }else if(exNo == 3){
    if(case == 1){
      coef = cbind(c(-2.76,-3.04, -2.39),
                   c(-2.76, 0,     2.39),
                   c( 2.76, 3.04,  2.39))
      K = ncol(coef)
      id = sample(1:K, n, replace = TRUE)
    }else if(case == 2){
      b = c(-2.74, 3.35, -3.08)
      coef = cbind(c(-2.76,-3.04, -2.39, b),
                   c(-2.76, 0,     2.39, b),
                   c( 2.76, 3.04,  2.39, b))
      K = ncol(coef)
      id = sample(1:K, n, replace = TRUE)
    }else if(case == 3){
      b = c(-2.74, 3.35, -3.08)
      coef = cbind(c(-2.76,-3.04, -2.39, b),
                   c(-2.76, 0, 2.39, b),
                   c( 2.76, 3.04,  2.39, b))
      K = ncol(coef)
      id = sample(1:K, n, replace = TRUE, prob=c(0.15,0.3,0.55))
    }else{
      coef = matrix(c(-2.74, 3.35, -3.08), ncol = 1)
      K = 1
      id = rep(1, n)
    }
    d = nrow(coef)
    R = chol(matrix(0.5, d,d)^abs(matrix(1:d, d,d)-t(matrix(1:d,d,d))))
    x = matrix(rnorm(n*d), n, d)%*%R
    x[, 1] = sample(c(1,0), n, replace = T, prob=c(0.2,0.8))
    x[, 2] = sample(c(0,1,2,3), n, replace = T, prob = c(0.4,0.3,0.2,0.1))
    y = rep(0, n)
    for(k in 1:K){
      y[id == k] = x[id == k, ]%*%coef[, k]
    }
    y = as.vector( y + rt(n, 3) )#rnorm(n)
  }
  # return(list(data = data.frame(x = x, y = y, clusters0 = id), coef = coef))
  return(list(x = x, y = y, clusters0 = id))
}


DGP_nlm <- function(n, case = 1){
  coef = cbind(c(1,-2),c(1,2))
  K = 2
  d = 2
  id = sample(1:K, n, replace = TRUE)
  if(case == 1){
    x = matrix(rnorm(n*d), n, d)%*%chol(matrix(c(1,0.5,0.5,1), d))
    y = rep(0, n)
    for(k in 1:K){
      y[id == k] = (x[id == k, ]%*%coef[, k])^3
    }
    y = as.vector( y + rnorm(n) )
  }else{
    x = matrix(rnorm(n*d), n, d)%*%chol(matrix(c(1,0.5,0.5,1), d))
    y = rep(0, n)
    for(k in 1:K){
      y[id == k] = sin(pi*x[id == k, 1]*coef[1,k]) + x[id==k, 2]*coef[2,k]
    }
    y = as.vector( y + sqrt(0.5)*rnorm(n) )
  }
  # return(list(data = data.frame(x = x, y = y, clusters0 = id), coef = coef))
  return(list(x = x, y = y, clusters0 = id))
}



evaluate_estimate = function(coef, coefhat){
  # only compute the iteration in which the numbers of clusters are correctlly estimated
  # first pick up the right clusters
  K = ncol(coef)
  d = nrow(coef)
  K_hat = sapply(coefhat, ncol)
  if(sum(K_hat==K) == 0){
    return(cbind(rep(0, K), rep(0, K)))
  }else{
    pr = mean(K_hat == K)
    coefhat = coefhat[K_hat == K]
    RMSE = NULL
    for(k in 1:K){
      coefhat_k = sapply(coefhat, function(x) x[, which.min(sqrt(colMeans( (x - coef[, k])^2 )) )] )
      RMSE = cbind( RMSE, sqrt( colMeans( (coefhat_k - coef[, k])^2 ) ) )
    }
    RMSE_mean = round(apply(RMSE, 2, mean), 4)
    RMSE_sd = round(apply(RMSE, 2, sd), 4)
    return(cbind(RMSE_mean, RMSE_sd))
  }
}


