# CWM algorithm
# this algorithm is from the paper flexCWM
library(flexCWM)
flexibleCWM <- function(x, y, N){
  if( all(x[,1] == 1) ){
    xx = x[,2]
    fit1 <- cwm(y ~ xx, Xnorm=xx, k=1:N, modelXnorm = c("E","V")) #
  }else{
    fit1 <- cwm(y ~ x, Xnorm=x, k=1:N, modelXnorm = "VEE") #
  }
  clusters_cwm = getCluster(fit1)
  K_opt = length(unique(clusters_cwm))
  clusters_mem = lapply(as.list(1:K_opt), function(v) which(clusters_cwm == v))
  centers = matrix(0, ncol(x), K_opt)
  lam = 0.01
  p = ncol(x)
  for(k in 1:K_opt){
    g = clusters_mem[[k]]
    gram_mat = t(x[g,])%*%x[g,]
    if(is.singular.matrix(gram_mat)){
      # if the matrix is singular, useing the ridge estimator
      centers[, k] = solve(gram_mat + diag(lam,p,p))%*%t(x[g,])%*%y[g]
    }else{
      centers[, k] = solve(gram_mat)%*%t(x[g,])%*%y[g]
    }
  }
  return(list(clusters = clusters_cwm, centers = centers))
}

