# rm(list=ls()) 
library(fossil) # package for evaluating clustering
source("general_functions.R")
source("functions_nlm.R")
# generate the data
n <- 200
iter <- 200
X <- list() 
Y <- list()
Clusters <- list()
coef = cbind(c(1, -2), c(1, 2)) # modelNo = 1
# coef = cbind(c(1,-2), c(1,2)) # modelNo = 2
modelNo = 1
for (i in 1:iter) {
  data <- DGP_nlm(coef, modelNo)
  X[[i]] <- data$x
  Y[[i]] <- data$y
  Clusters[[i]] <- data$clusters0
  # x = data$x; y = data$y; 
}

# get initial estimate for beta
N <- 3
anchors <- getAnchors(data$x, data$y, N, modelNo)
results_GRC <- lapply(1:iter, function(i) {
  try(GRC_nlm(X[[i]], Y[[i]], anchors, modelNo), TRUE)
})

id_GRC <- which(sapply(results_GRC, function(v) !("try-error" %in% class(v)))) 
RI_GRC <- sapply(id_GRC, function(i) rand.index(results_GRC[[i]]$clusters, Clusters[[i]]))
ARI_GRC <- sapply(id_GRC, function(i) adj.rand.index(results_GRC[[i]]$clusters, Clusters[[i]]))
K_GRC <- sapply(id_GRC, function(i) ncol(results_GRC[[i]]$centers))
coefhat_GRC <- lapply(id_GRC, function(i) results_GRC[[i]]$centers) 

K <- ncol(coef)
sumRes_GRC <- round(c(
  mean(K_GRC == K), mean(K_GRC), sd(K_GRC),
  mean(RI_GRC), sd(RI_GRC), mean(ARI_GRC), sd(ARI_GRC),
  as.vector(t(evaluate_estimate(coef, coefhat_GRC)))), 4)


